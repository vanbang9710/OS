./consumer
diff --report-identical-files "input.dat" "output.dat"